import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { selectAllTests } from '../../redux/slices/brainTestSlice'; // Ensure the path is correct
import Header from "../../components/Header";
import BrainTestCard from '../../components/BrainTestCard'; // Ensure the path is correct

//import BrainTestCard from '../../components/main/BrainTestCard'; // Ensure the path is correct

const BrainTestScreen = () => {
  const tests = useSelector(selectAllTests);
  const navigation = useNavigation();

  const handleTestPress = (test) => {
    navigation.navigate('ParkinsonTestScreen', { testId: test.id }); // Updated navigation to ParkinsonTestScreen
  };

  return (
    <SafeAreaView style={styles.container}>
      <Header />
      <View style={styles.content}>
        <Text style={styles.title}>Brain Test</Text>
        <View style={styles.cardContainer}>
          <FlatList
            data={tests}
            numColumns={2}
            renderItem={({ item }) => (
              <BrainTestCard test={item} onPress={handleTestPress} />
            )}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.listContent}
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#4B50D6',
    marginBottom: 16,
  },
  cardContainer: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 16,
    padding: 8,
    backgroundColor: '#fff',
  },
  listContent: {
    paddingVertical: 8,
  },
});

export default BrainTestScreen;