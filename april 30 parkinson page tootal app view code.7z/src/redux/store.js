import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import userReducer from './slices/userSlice';
import healthReducer from './slices/healthSlice';
import patientsReducer from './slices/patientsSlice';
import brainTestReducer from './slices/brainTestSlice';
import parkinsonTestReducer from './slices/parkinsonTestSlice';


export const store = configureStore({
  reducer: {
    auth: authReducer,
    user: userReducer,
    health: healthReducer,
    patients: patientsReducer,
    brainTest: brainTestReducer,
    parkinsonTest: parkinsonTestReducer,
  
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

export default store;
