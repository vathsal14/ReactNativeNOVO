export const API_BASE_URL = 'https://your-api-base-url.com/api';
// Add other constants as needed
