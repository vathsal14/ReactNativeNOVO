import React from 'react'

const HomeScreen = () => {
  return (
    <div>HomeScreen</div>
  )
}

export default HomeScreen